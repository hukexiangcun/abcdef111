import numpy as np
ang = np.random.rand(5,5)*2*np.pi
np.savetxt('kernel.txt',ang)