""" Spherical harmonics transforms/inverses and spherical convolution. """


import functools
import numpy as np
import torch
import torchvision
import torch.nn as nn
import itertools
from functools import reduce

import torch.nn.functional as F
import math
from math import cos,atan
from .dis_convolutional import dis_conv

CCD_length = 7.7
CCD_width = 5.5
ox = CCD_width/2
oy = CCD_length/2
a = 8.3
k = 4
dx = 0.00859375
dy = 0.00859375
f = 8
#a0 = 0.1
# cache outputs; 2050 > 32*64

class dis_convolution(nn.Module):
    def __init__(self):
        super(dis_convolution, self).__init__()
        
        w0=512
        h0=128
        self.bn0 = np.zeros((h0,w0))
        for j in range(w0):
            for i in range(h0):
            
                a0 = atan(dx*((j)-ox)/f)
                
                self.bn0[i,j] = int(i-((cos(a0)-1)*((i)-oy)))
                
                if self.bn0[i,j]<0:
                    self.bn0[i,j] = 0
                if self.bn0[i,j]>=h0:
                    self.bn0[i,j] = h0-1            
    def forward(self, x):
        
        x1 = x[:,:,self.bn0,self.bn0]
                        
        out = x1.cuda()
        #print(out.shape)
        return out
            

   