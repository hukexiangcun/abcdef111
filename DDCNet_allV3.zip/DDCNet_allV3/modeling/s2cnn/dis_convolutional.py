import functools
import numpy as np
import torch
import torch.nn as nn
import itertools
from functools import reduce

import torch.nn.functional as F
import math
from math import cos,atan

#CCD相机参数
CCD_length = torch.Tensor([7.7])
CCD_width = torch.Tensor([5.5])
ox = CCD_width/2
oy = CCD_length/2
dx = torch.Tensor([0.00859375])
dy = torch.Tensor([0.00859375])
f = torch.Tensor([8])

class dis_conv(nn.Module):
    def __init__(self, w, h, batch_size):
        super(dis_conv,self).__init__()
        w0, h0 = w, h
        self.bn = torch.zeros(h0,w0,dtype=torch.int64)
        for i in range(h0):
            for j in range(w0):
                a0 = torch.atan(dx*(torch.Tensor(j)-ox)/f)
                self.bn[i,j] = ((cos(a0)-1)*(torch.Tensor(i)-oy))
        
    def forward(self,input):
        
        
        
        return out
        
        
                